from setuptools import setup, find_packages

setup(
    name="mercurydsa",
    version="0.0.4",
    author="Walter Michel Raja",
    author_email="waltermichelraja@gmail.com",
    packages=find_packages()
)