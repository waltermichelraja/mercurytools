# mercuryds
data structures made easy
